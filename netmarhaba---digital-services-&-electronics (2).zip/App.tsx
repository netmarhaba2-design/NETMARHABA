import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Menu, X, Globe, ChevronRight, FileText, Smartphone, Laptop, 
  CreditCard, Printer, Monitor, Download, ArrowRight, ShieldCheck, 
  ShoppingCart, Star, Phone, Mail, Send, CheckCircle2, History
} from 'lucide-react';
import { translations } from './translations';

// --- Logo Component ---
const Logo = ({ className = "w-10 h-10" }: { className?: string }) => (
  <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 80V20L50 50L80 20V80" stroke="currentColor" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="50" cy="50" r="8" fill="currentColor"/>
    <path d="M20 20L80 80M20 80L80 20" stroke="currentColor" strokeWidth="4" strokeOpacity="0.2"/>
  </svg>
);

// --- Animation Variants ---
const fadeInUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, ease: [0.33, 1, 0.68, 1] }
};

const staggerContainer = {
  animate: { transition: { staggerChildren: 0.1 } }
};

export default function App() {
  const [lang, setLang] = useState<'fr' | 'ar'>('fr');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const t = translations[lang];

  useEffect(() => {
    // Simulated loader
    const timer = setTimeout(() => setIsLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  const toggleLang = () => {
    setLang(lang === 'fr' ? 'ar' : 'fr');
  };

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-white flex flex-col items-center justify-center z-50">
        <motion.div
          animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className="text-brick mb-4"
        >
          <Logo className="w-20 h-20" />
        </motion.div>
        <motion.h1 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-2xl font-bold tracking-widest text-brick"
        >
          NETMARHABA
        </motion.h1>
        <motion.div 
          className="w-48 h-1 bg-gray-100 mt-6 rounded-full overflow-hidden"
        >
          <motion.div 
            className="h-full bg-brick"
            initial={{ width: 0 }}
            animate={{ width: "100%" }}
            transition={{ duration: 1.8 }}
          />
        </motion.div>
      </div>
    );
  }

  return (
    <div dir={lang === 'ar' ? 'rtl' : 'ltr'} className="min-h-screen bg-white custom-scrollbar selection:bg-red-100 selection:text-red-900">
      
      {/* --- Navigation --- */}
      <nav className="fixed top-0 w-full z-40 glass-card bg-white/70 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center gap-3">
              <div className="text-brick">
                <Logo className="w-9 h-9" />
              </div>
              <span className="text-xl font-extrabold tracking-tighter text-gray-900">NETMARHABA</span>
            </div>

            <div className="hidden md:flex items-center gap-8">
              {Object.entries(t.nav).map(([key, value]) => (
                <a key={key} href={`#${key}`} className="text-sm font-semibold text-gray-600 hover:text-brick transition-colors">
                  {value}
                </a>
              ))}
            </div>

            <div className="flex items-center gap-4">
              <button 
                onClick={toggleLang}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-gray-200 text-sm font-bold hover:bg-gray-50 transition-all"
              >
                <Globe size={16} />
                {lang === 'fr' ? 'العربية' : 'Français'}
              </button>
              
              <button className="md:hidden text-gray-900" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden bg-white border-b border-gray-100 overflow-hidden"
            >
              <div className="px-4 pt-2 pb-6 space-y-1">
                {Object.entries(t.nav).map(([key, value]) => (
                  <a 
                    key={key} 
                    href={`#${key}`} 
                    className="block px-3 py-4 text-base font-bold text-gray-700 hover:text-brick"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {value}
                  </a>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* --- Hero Section --- */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full -z-10 opacity-30 pointer-events-none">
          <div className="absolute top-0 right-0 w-96 h-96 bg-red-100 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-gray-100 rounded-full blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: lang === 'ar' ? 50 : -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-red-50 text-brick text-xs font-black uppercase tracking-widest mb-6"
              >
                <ShieldCheck size={14} />
                {t.finance.secure}
              </motion.div>
              <h1 className="text-5xl lg:text-7xl font-extrabold text-gray-900 leading-[1.1] mb-6">
                {t.hero.title.split(' ').map((word, i) => (
                  <span key={i} className={i === 2 ? "text-brick" : ""}>{word} </span>
                ))}
              </h1>
              <p className="text-lg lg:text-xl text-gray-500 max-w-xl leading-relaxed mb-10">
                {t.hero.subtitle}
              </p>
              <div className="flex flex-wrap gap-4">
                <button className="light-sweep px-8 py-4 bg-brick text-white font-bold rounded-2xl flex items-center gap-3 hover:bg-brick-hover shadow-xl shadow-red-200 transition-all">
                  {t.hero.cta_services}
                  {lang === 'fr' ? <ArrowRight size={20} /> : <ArrowRight className="rotate-180" size={20} />}
                </button>
                <button className="px-8 py-4 bg-white border-2 border-gray-100 text-gray-900 font-bold rounded-2xl hover:bg-gray-50 transition-all">
                  {t.hero.cta_store}
                </button>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1 }}
              className="relative hidden lg:block"
            >
              <div className="relative z-10 w-full aspect-square bg-gray-50 rounded-[3rem] overflow-hidden border-8 border-white shadow-2xl">
                 <img 
                   src="https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?auto=format&fit=crop&q=80&w=1000" 
                   alt="Modern Services" 
                   className="w-full h-full object-cover grayscale opacity-80"
                 />
                 <div className="absolute inset-0 bg-gradient-to-tr from-brick/40 to-transparent" />
              </div>
              <motion.div 
                animate={{ y: [0, -20, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -top-6 -right-6 p-6 glass-card rounded-3xl shadow-xl z-20"
              >
                <div className="bg-green-500 w-12 h-12 rounded-full flex items-center justify-center text-white mb-3">
                  <CheckCircle2 size={24} />
                </div>
                <div className="font-bold text-gray-900">Traitement Express</div>
                <div className="text-xs text-gray-500">Service 24/7 disponible</div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* --- Services Section --- */}
      <section id="services" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <div>
              <h2 className="text-4xl font-extrabold text-gray-900 mb-4">{t.services.title}</h2>
              <div className="w-20 h-1.5 bg-brick rounded-full" />
            </div>
            <p className="text-gray-500 max-w-md">{lang === 'fr' ? 'Accédez à vos documents administratifs sans file d\'attente, directement en ligne.' : 'احصل على وثائقك الإدارية دون عناء التنقل، مباشرة عبر الإنترنت.'}</p>
          </div>

          <motion.div 
            variants={staggerContainer}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8"
          >
            {[
              { icon: FileText, title: t.services.birth, desc: "Extraction rapide" },
              { icon: ShieldCheck, title: t.services.criminal, desc: "Sûreté garantie" },
              { icon: Smartphone, title: t.services.marriage, desc: "Simple & mobile" },
              { icon: Download, title: t.services.forms, desc: "Prêt à remplir" }
            ].map((s, i) => (
              <motion.div key={i} variants={fadeInUp} className="group hover-lift p-8 bg-white rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-2xl bg-red-50 text-brick flex items-center justify-center mb-6 group-hover:bg-brick group-hover:text-white transition-all duration-300">
                  <s.icon size={30} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{s.title}</h3>
                <p className="text-sm text-gray-400 mb-6">{s.desc}</p>
                <button className="mt-auto flex items-center gap-2 text-brick font-bold text-sm hover:underline">
                  {i === 3 ? t.services.download : "Détails"}
                  <ChevronRight size={16} />
                </button>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* --- Flexy Recharge --- */}
      <section id="flexy" className="py-24 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gray-900 rounded-[3rem] overflow-hidden p-8 lg:p-16 flex flex-col lg:flex-row items-center gap-16 relative">
            <div className="absolute top-0 right-0 w-full h-full opacity-10 pointer-events-none bg-[radial-gradient(circle_at_top_right,_#B22222_0%,_transparent_50%)]" />
            
            <div className="lg:w-1/2">
              <h2 className="text-4xl font-extrabold text-white mb-6">{t.flexy.title}</h2>
              <p className="text-gray-400 mb-10 text-lg leading-relaxed">{lang === 'fr' ? 'Rechargez votre crédit Mobilis, Djezzy ou Ooredoo instantanément avec notre système sécurisé.' : 'عبئ رصيدك موبيليس، جيزي أو أوريدو فوراً عبر نظامنا الآمن.'}</p>
              
              <div className="grid grid-cols-3 gap-4 mb-10">
                {['Mobilis', 'Djezzy', 'Ooredoo'].map((op, i) => (
                  <motion.div 
                    whileHover={{ scale: 1.05 }}
                    key={op} 
                    className={`p-4 rounded-2xl border ${i === 0 ? 'bg-green-500/10 border-green-500 text-green-500' : 'bg-white/5 border-white/10 text-white'} flex flex-col items-center gap-2 cursor-pointer transition-all`}
                  >
                    <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center font-black">
                      {op[0]}
                    </div>
                    <span className="text-xs font-bold">{op}</span>
                  </motion.div>
                ))}
              </div>

              <div className="flex items-center gap-4 text-gray-400">
                <History size={20} />
                <span className="text-sm">Historique de vos recharges disponible sur votre compte</span>
              </div>
            </div>

            <div className="lg:w-1/2 w-full">
              <div className="bg-white rounded-3xl p-8 shadow-2xl">
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">{t.flexy.phone}</label>
                    <input type="text" placeholder="0X XX XX XX XX" className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-brick/20 transition-all font-mono" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">{t.flexy.amount}</label>
                    <input type="number" placeholder="100 - 5000" className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-brick/20 transition-all font-mono" />
                  </div>
                  <button className="w-full py-4 bg-brick text-white font-black rounded-2xl flex items-center justify-center gap-3 hover:bg-brick-hover transition-all shadow-lg shadow-red-100">
                    <Smartphone size={20} />
                    {t.flexy.submit}
                  </button>
                  <div className="flex items-center justify-center gap-2 text-xs text-gray-400 font-bold uppercase tracking-widest">
                    <ShieldCheck size={14} className="text-green-500" />
                    Paiement Sécurisé SSL
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* --- Electronics Store --- */}
      <section id="store" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between mb-16 gap-6">
            <h2 className="text-4xl font-extrabold text-gray-900">{t.store.title}</h2>
            <div className="flex gap-4">
              <button className="p-3 bg-gray-100 rounded-2xl text-gray-400 hover:text-brick transition-all">
                <Menu size={20} />
              </button>
              <button className="px-5 py-2.5 bg-brick text-white rounded-2xl text-sm font-bold flex items-center gap-2">
                <ShoppingCart size={18} />
                Panier (0)
              </button>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-10">
            {[
              { name: "Smartphone Ultra", price: "45,000 DA", img: "https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&q=80&w=400" },
              { name: "Laptop Pro X", price: "120,000 DA", img: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&q=80&w=400" },
              { name: "Casque ANC Elite", price: "15,000 DA", img: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=400" }
            ].map((p, i) => (
              <motion.div 
                key={i} 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="group p-4 bg-white rounded-[2rem] border border-gray-100 hover:shadow-xl transition-all"
              >
                <div className="relative aspect-[4/3] bg-gray-50 rounded-2xl overflow-hidden mb-6">
                  <img src={p.img} alt={p.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                  <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-[10px] font-black text-brick uppercase tracking-wider">
                    {t.store.stock}
                  </div>
                </div>
                <div className="px-2 pb-2">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-bold text-gray-900">{p.name}</h3>
                    <div className="flex items-center gap-1 text-yellow-500">
                      <Star size={14} fill="currentColor" />
                      <span className="text-xs font-bold text-gray-400">4.9</span>
                    </div>
                  </div>
                  <div className="text-brick font-black text-xl mb-6">{p.price}</div>
                  <button className="w-full py-3 bg-gray-900 text-white font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-brick transition-all">
                    <ShoppingCart size={18} />
                    {t.store.buy}
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* --- Finance Section --- */}
      <section id="finance" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              className="p-10 lg:p-16 bg-white rounded-[3rem] shadow-sm border border-gray-100"
            >
              <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-8">
                <CreditCard size={32} />
              </div>
              <h2 className="text-3xl font-extrabold text-gray-900 mb-6">{t.finance.vcc}</h2>
              <p className="text-gray-500 mb-10 leading-relaxed">Paiement sécurisé et activation immédiate de vos cartes virtuelles pour vos achats internationaux (Netflix, Amazon, AliExpress).</p>
              <button className="flex items-center gap-2 font-black text-blue-600 group">
                Consulter les tarifs
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              className="p-10 lg:p-16 bg-gray-900 rounded-[3rem] shadow-xl text-white relative overflow-hidden"
            >
              <div className="relative z-10">
                <div className="w-16 h-16 rounded-2xl bg-brick/20 text-brick flex items-center justify-center mb-8">
                  <ShieldCheck size={32} />
                </div>
                <h2 className="text-3xl font-extrabold mb-6">{t.finance.usdt}</h2>
                <p className="text-gray-400 mb-10 leading-relaxed">Vendez ou achetez vos cryptomonnaies USDT au meilleur taux du marché avec un support dédié.</p>
                <button className="flex items-center gap-2 font-black text-brick group">
                  Démarrer l'échange
                  <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
              <div className="absolute top-0 right-0 w-64 h-64 bg-brick/10 blur-[100px] -z-0" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* --- Secondary Services Grid --- */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-8 rounded-[2.5rem] bg-gray-50 flex items-start gap-6 group hover:bg-white hover:shadow-xl transition-all border border-transparent hover:border-gray-100">
              <div className="p-4 rounded-2xl bg-white text-gray-900 group-hover:bg-brick group-hover:text-white transition-all shadow-sm">
                <Printer size={24} />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 mb-2">{t.others.print}</h3>
                <p className="text-sm text-gray-400">Haute qualité laser</p>
              </div>
            </div>
            <div className="p-8 rounded-[2.5rem] bg-gray-50 flex items-start gap-6 group hover:bg-white hover:shadow-xl transition-all border border-transparent hover:border-gray-100">
              <div className="p-4 rounded-2xl bg-white text-gray-900 group-hover:bg-brick group-hover:text-white transition-all shadow-sm">
                <FileText size={24} />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 mb-2">{t.others.invoice}</h3>
                <p className="text-sm text-gray-400">Automatisé & Professionnel</p>
              </div>
            </div>
            <div className="p-8 rounded-[2.5rem] bg-gray-50 flex items-start gap-6 group hover:bg-white hover:shadow-xl transition-all border border-transparent hover:border-gray-100">
              <div className="p-4 rounded-2xl bg-white text-gray-900 group-hover:bg-brick group-hover:text-white transition-all shadow-sm">
                <Monitor size={24} />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 mb-2">{t.others.datashow}</h3>
                <p className="text-sm text-gray-400">{t.others.rental_btn}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* --- Contact Section --- */}
      <section id="contact" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-brick rounded-[3rem] p-8 lg:p-20 text-white flex flex-col lg:flex-row gap-16">
            <div className="lg:w-1/3">
              <h2 className="text-4xl font-extrabold mb-8">{t.nav.contact}</h2>
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center">
                    <Phone size={20} />
                  </div>
                  <div>
                    <div className="text-xs text-red-200 font-bold uppercase">Téléphone</div>
                    <div className="font-bold">+213 (0) XX XX XX XX</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center">
                    <Mail size={20} />
                  </div>
                  <div>
                    <div className="text-xs text-red-200 font-bold uppercase">Email</div>
                    <div className="font-bold">contact@netmarhaba.dz</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:w-2/3">
              <form className="grid sm:grid-cols-2 gap-6">
                <input type="text" placeholder="Nom complet" className="bg-white/10 border border-white/20 rounded-2xl px-6 py-4 focus:outline-none focus:bg-white/20 transition-all placeholder:text-red-100" />
                <input type="email" placeholder="Email" className="bg-white/10 border border-white/20 rounded-2xl px-6 py-4 focus:outline-none focus:bg-white/20 transition-all placeholder:text-red-100" />
                <textarea placeholder="Votre message..." rows={4} className="sm:col-span-2 bg-white/10 border border-white/20 rounded-2xl px-6 py-4 focus:outline-none focus:bg-white/20 transition-all placeholder:text-red-100" />
                <button className="sm:col-span-2 py-4 bg-white text-brick font-black rounded-2xl flex items-center justify-center gap-3 hover:bg-red-50 transition-all group">
                  <Send size={20} />
                  Envoyer le message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* --- Footer --- */}
      <footer className="py-12 bg-gray-50 border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-3">
              <div className="text-brick">
                <Logo className="w-8 h-8" />
              </div>
              <span className="text-lg font-extrabold tracking-tighter text-gray-900 uppercase">NETMARHABA</span>
            </div>

            <p className="text-sm text-gray-400 font-medium">
              {t.footer.rights}
            </p>

            <div className="flex gap-6 text-xs font-bold text-gray-500 uppercase tracking-widest">
              <a href="#" className="hover:text-brick">Privacy</a>
              <a href="#" className="hover:text-brick">Terms</a>
              <a href="#" className="hover:text-brick">Status</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}