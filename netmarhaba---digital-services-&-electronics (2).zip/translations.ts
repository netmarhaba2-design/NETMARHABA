
export const translations = {
  fr: {
    nav: {
      services: "Services",
      store: "Boutique",
      flexy: "Recharge",
      finance: "Finance",
      rental: "Location",
      contact: "Contact",
    },
    hero: {
      title: "Votre Partenaire Numérique de Confiance",
      subtitle: "Simplifiez vos démarches administratives, rechargez vos comptes et accédez aux meilleures technologies.",
      cta_services: "Découvrir les Services",
      cta_store: "Visiter la Boutique",
    },
    services: {
      title: "Services Administratifs",
      birth: "Extrait de Naissance",
      criminal: "Casier Judiciaire",
      marriage: "Acte de Mariage",
      forms: "Formulaires à Télécharger",
      download: "Télécharger PDF",
    },
    flexy: {
      title: "Recharge Mobile Flexy",
      operator: "Opérateur",
      amount: "Montant (DA)",
      phone: "Numéro de téléphone",
      submit: "Recharger Maintenant",
      fast: "Traitement Instantané",
    },
    store: {
      title: "Boutique Électronique",
      buy: "Acheter",
      stock: "En stock",
    },
    finance: {
      title: "Cartes Virtuelles & USDT",
      vcc: "Recharge Cartes Virtuelles",
      usdt: "Achat/Vente USDT",
      secure: "Transactions 100% Sécurisées",
    },
    others: {
      invoice: "Création de Factures",
      print: "Impression Documents",
      datashow: "Location DataShow",
      rental_btn: "Réserver Maintenant",
    },
    footer: {
      rights: "© 2025 NETMARHABA. Tous droits réservés.",
      support: "Support 24/7",
    }
  },
  ar: {
    nav: {
      services: "الخدمات",
      store: "المتجر",
      flexy: "تعبئة الرصيد",
      finance: "المالية",
      rental: "كراء",
      contact: "اتصل بنا",
    },
    hero: {
      title: "شريكك الرقمي الموثوق",
      subtitle: "بسط إجراءاتك الإدارية، عبئ رصيدك واحصل على أفضل التقنيات.",
      cta_services: "اكتشف الخدمات",
      cta_store: "زيارة المتجر",
    },
    services: {
      title: "الخدمات الإدارية",
      birth: "استخراج شهادة الميلاد",
      criminal: "استخراج السوابق العدلية",
      marriage: "استخراج عقد الزواج",
      forms: "تحميل الاستمارات",
      download: "تحميل PDF",
    },
    flexy: {
      title: "تعبئة رصيد الهاتف (Flexy)",
      operator: "المتعامل",
      amount: "المبلغ (دج)",
      phone: "رقم الهاتف",
      submit: "تعبئة الآن",
      fast: "معالجة فورية",
    },
    store: {
      title: "متجر الإلكترونيات",
      buy: "شراء",
      stock: "متوفر",
    },
    finance: {
      title: "البطاقات الافتراضية و USDT",
      vcc: "شحن البطاقات الافتراضية",
      usdt: "شراء وبيع USDT",
      secure: "تعاملات آمنة 100%",
    },
    others: {
      invoice: "خدمة إنشاء الفواتير",
      print: "خدمات الطباعة",
      datashow: "كراء داتاشو (DataShow)",
      rental_btn: "احجز الآن",
    },
    footer: {
      rights: "© 2025 نت مرحبا. جميع الحقوق محفوظة.",
      support: "دعم فني 24/7",
    }
  }
};
